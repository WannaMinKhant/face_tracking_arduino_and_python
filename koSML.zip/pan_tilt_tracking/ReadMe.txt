# to run script of pan_tilt_tracking code

python3 pan_tilt_tracking.py --cascade haarcascade_frontalface_default.xml

this code is reference of pyimagesearch.com.But arduino code and motor control of python code are self innovation of wannaminkhant